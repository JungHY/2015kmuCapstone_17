﻿using UnityEngine;
using System.Collections;

public class AnimationSample : MonoBehaviour {

    Animator animator;

	// Use this for initialization
	void Start () {
        animator = GetComponent(typeof(Animator)) as Animator;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            animator.Play("ui1");
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            animator.Play("ui2");
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            animator.Play("ui3");
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            animator.Play("ui4");
        }
    }
}
