﻿using Microsoft.Kinect;
using System.Diagnostics;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using System.Windows;
using System;
using System.IO;
using System.Windows.Media;
using System.Collections.Generic;

namespace KinectUI
{
    static class Contants
    {
        public static double calc_spline_curve(double p0, double p1, double p2, double p3, double[] t)
        {
            return (0.5f * ((2.0f * p1) + (-p0 + p2) * t[0] + (2.0f * p0 - 5.0f * p1 + 4 * p2 - p3) * t[1] + (-p0 + 3.0f * p1 - 3.0f * p2 + p3) * t[2]));
        }
    }
    public partial class ToolBar
    {

        //init
        // Flag --------------------------------------
        private bool openFlag = true;                    
        private bool optionFlag = true;
        private bool penFlag = false;
        private bool keyboardFlag = false;
        private bool captureFlag = false;
        private bool usermodeFlag = false;
        // 새로 추가된 부분 -------------------------------
        public static int BLUE_COLOR_LIMIT = 7;                       
        public static int RED_COLOR_LIMIT = 14;
        public static int DEPTH_MAX_LIMIT = 2000;
        public static int SCREEN_PIXEL_WIDTH = 640;
        public static int SCREEN_PIXEL_HEIGHT = 480;
        public static int COLOR_CHANNEL = 4;
        public static int PIXEL_CNT_MIN_LIMIT = 40;
        public static int PIXEL_CNT_MAX_LIMIT = 400;
        public static int SQUARE_POINT_CNT = 4;
        public static int MOVE_POINT = 400;
        public static int UNCHANGED_FRAME_CNT = 5;
        public static int PRESSED_FRAME_CNT = 20;
        public static int PEN_MOVE_MAX_LIMIT = 49;
        public static int PEN_MOVE_MIN_LIMIT = 3;
        public static int GESTURE_MOVE_LIMIT = 100;
        public static int SCREEN_DISTANCE_LIMIT = 100;
        public static int WHEEL_VARIATION = 30;
        public static int MIN_ARRAY_INIT = 700;
        public static int MAX_ARRAY_INIT = -1;
        public static int SUB_DISTANCE_LIMIT = 900;
        public static double COMPUTER_X = 1600.0;                      // 화면 해상도 Width
        public static double COMPUTER_Y = 900.0;                       // 화면 해상도 Height    
        public static double SPLINE_T = 10;
        public static int MAX_POINT_SPLINE = 4;
        public static int USER_CNT = 50;
        // ------------------------------------------------
        PenTool pentool;
        Process keyProcess;                                                      // 키보드 프로세스
        private Queue<TouchPoint> TracePoint = new Queue<TouchPoint>();
        private TouchPoint[] penPointList = new TouchPoint[4];
        private LinkedList<TouchPoint> PointList = new LinkedList<TouchPoint>();
        private KinectSensor nui;                                                // 키넥트 센서 변수
        private SetUp setup;                                                     // 옵션창 객체 생성
        private DepthImagePixel[] depthPixels;                                   // 현재 Depth 저장
        private DepthImagePixel[] initDepthPixels;                               // 초기 Depth 저장
        private WriteableBitmap colorBitmap;                                     // 화면의 출력할 Color Map
        private Line[] MyLine = new Line[4];                                      // SCREEN 사각형
        private Ellipse[] myEllipse = new Ellipse[4];                            // TouchPoint 위치 생성할 원
        private ColorImagePoint[] mappedDepthLocations;
        private short[,] depthPixel = new short[SCREEN_PIXEL_HEIGHT, SCREEN_PIXEL_WIDTH];      // 화면 좌우 반전을 위해 2차원 배열로 저장
        private short[,] initdepthPixel = new short[SCREEN_PIXEL_HEIGHT, SCREEN_PIXEL_WIDTH];  // 화면 좌우 반전을 위해 2차원 배열로 저장
        private System.Windows.Point pre_Point1 = new System.Windows.Point(0, 0);
        private System.Windows.Point pre_Point2 = new System.Windows.Point(0, 0);                     // TouchPoint 저장변수
        private System.Windows.Point rightPoint;                                 // 우클릭 인식 좌표
        private System.Windows.Point[] screenPoint = new System.Windows.Point[4]; // SCREEN 4 모퉁이 좌표
        private bool start = false;                             // 키넥트센서 시작 정지 
        private bool init = true;                               // 초기 Depth 저장을 위한 변수
        private bool ScreenDraw = false;                        // SCREEN 캘리 변수  
        private bool mouseUse = false;                          // 마우스사용 Flag                         
        private bool rightFlag = true;                          // 우클릭 이벤트 Flag
        private bool gestureFlag = false;                       // 제스쳐 이벤트 Flag
        private bool penTool_Flag = false;                      // 펜툴창 생성 Flag
        private byte[] VirKey = new byte[256];                                   // 키보드
        private byte[] _colorPixels = new byte[0];
        private byte[] bitmapBits = new byte[SCREEN_PIXEL_HEIGHT * SCREEN_PIXEL_WIDTH * COLOR_CHANNEL];
        private short[] _depthPixels = new short[0];                             // Depth값을 Color값으로 변경
        private int[] SearchArea = new int[4];
        private int moveLimit = 49;                             // TouchPoint 변화보정 변수
        private int penMoveLimit = 49;
        private int screenCnt = 0;                              // SCREEN 모서리 생성 개수
        private int pixelCnt = 0;                               // TouchPoint의 최소 픽셀 개수
        private int pointCnt = 0;                               // TouchPoint 개수
        private int s_Row = 0;                                  // TouchPoint를 만드는 픽셀의 가로합
        private int s_Col = 0;                                  // TouchPoint를 만드는 픽셀의 세로합
        private int mode = 1;                                   // Mode 설정
        private int frameCnt = 0;                               // 프레임 카운트                          
        private double[] Perspective = new double[8];

        //init 
        public void init_myEllipse()
        {
            for (int i = 0; i < 4; i++)
                myEllipse[i] = new Ellipse();
        }
        
        public void init_myLine()
        {
            for (int i = 0; i < 4; i++)
                MyLine[i] = new Line();
        }
        

        //get function
        public bool get_start()
        {
            return start;
        }

        public WriteableBitmap get_colorBitmap()
        {
            return colorBitmap;
        }

        public Ellipse get_myEllipse(int num)
        {
            return myEllipse[num];
        }

        public bool get_ScreenDraw()
        {
            return ScreenDraw;
        }
        public Line get_MyLine(int i)
        {
            return MyLine[i];
        }
        public System.Windows.Point get_screenPoint(int i)
        {
            return screenPoint[i];
        }

        //set function
        public void set_screenCnt(int getValue)
        {
            screenCnt = getValue;
        }

        public void set_mouseUse(bool getValue)
        {
            mouseUse = getValue;
        }

        public void set_ScreenDraw(bool getValue)
        {
            ScreenDraw = getValue;
        }

        public void set_start(bool getValue)
        {
            start = getValue;
        }

        public void set_myEllipse()
        {
            for (int i = 0; i < 4; i++)
            {
                myEllipse[i].Fill = System.Windows.Media.Brushes.Green;
                myEllipse[i].Height = 10;
                myEllipse[i].Width = 10;
            }
        }

        public void set_myLine()
        {
            for (int i = 0; i < 4; i++)
            {
                MyLine[i].Stroke = System.Windows.Media.Brushes.Red;
                MyLine[i].StrokeThickness = 2;
            }
        }
        public void set_initdepthPixel()
        {
            init = true;
        }

        public void set_optionFlag(bool FlagValue)
        {
            optionFlag = FlagValue;
        }

        // Reset
        public void Reset_screen()
        {
            for (int i = 0; i < 4; i++)
                MyLine[i].StrokeThickness = 0;
        }

    }
}
