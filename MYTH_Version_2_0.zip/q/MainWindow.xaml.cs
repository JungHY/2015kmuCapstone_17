﻿using System;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Kinect;
using System.Windows.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;

class MouseEvent
{
    [DllImport("User32")]
    public static extern int GetCursorPos(out System.Windows.Point p);
}

namespace KinectUI
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ToolBar : Window
    {
        public ToolBar()
        {
            this.Topmost = true;
            InitializeComponent();
        }

        // 마우스이벤트 enum class
        public enum MouseEventFlag : int
        {
            Absolute = 0x8000,
            LeftDown = 0x0002,
            LeftUp = 0x0004,
            MiddleDown = 0x0020,
            MiddleUp = 0x0040,
            Move = 0x0001,
            RightDown = 0x0008,
            RightUp = 0x0010,
            Wheel = 0x0800,
            XDown = 0x0080,
            XUp = 0x0100,
            HWheel = 0x1000,
        }

        // 마우스버튼 enum class
        public enum MouseButton
        {
            Left,
            Right,
            Middle,
            Wheel,
            X,
        }
        // TouchPoint 추가
        public void add(double x, double y)
        {
            if (x < 0 || x > COMPUTER_X || y < 0 || y > COMPUTER_Y)
                return;

            TouchPoint P = new TouchPoint(x, y);
            PointList.AddLast(P);
            TracePoint.Enqueue(P);
            if (TracePoint.Count >= UNCHANGED_FRAME_CNT)
                TracePoint.Dequeue();
            pointCnt++;
            return;
        }

        // TouchPoint 갱신
        public void refresh(double x, double y)
        {
            foreach(var p in PointList)
            {
                double distance = (x - p.getX()) * (x - p.getX()) + (y - p.getY()) * (y - p.getY()); 
                if (distance < moveLimit)
                {
                    p.setExist(true);
                    return;
                }
                else if (distance < MOVE_POINT)
                {
                    p.setX(x);
                    p.setY(y);
                    p.setExist(true);
                    return;
                }
            }
            add(x, y);
        }


        // TouchPoint 전, 현 frame 비교 
        public void initExist()
        {
            foreach (var p in PointList)
                p.setExist(false);
        }

        // 없어진 TouchPoint Linked List에서 삭제
        public void removeNoneExist()
        {
            LinkedListNode<TouchPoint> R;
            for (R = PointList.First; R != null; )
            {
                if (!R.Value.getExist())
                {
                    if (R.Value.getrevision() > 5)
                    {
                        R.Value.setclick(false);
                        if (!gestureFlag)
                            Up(MouseButton.Left);
                        rightFlag = true;
                        PointList.Remove(R);
                        pointCnt--;
                        R.Value.setrevision(0);
                        R = PointList.First;
                    }
                    else
                    {
                        R.Value.revisionPlus();
                        R = R.Next;
                    }
                }
                else
                    R = R.Next;
            }
            initExist();
        }

        // 마우스, 키보드 사용하기위한 함수 
        [DllImport("user32.dll")]
        public static extern int SetCursorPos(int x, int y);
        [DllImport("user32.dll")]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, IntPtr dwExtraInfo);
        [DllImport("user32.dll")]
        private static extern int GetKeyboardState(byte[] pbKeyState);
        [DllImport("user32.dll")]
        static extern uint keybd_event(byte bVk, byte bScan, int dwFlags, int dwExtraInfo);
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        private static extern int SetForegroundWindow(IntPtr hwnd);

        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_RESTORE = 0xF120;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var potentialSensor in KinectSensor.KinectSensors)
            {
                if (potentialSensor.Status == KinectStatus.Connected)
                {
                    nui = KinectSensor.KinectSensors[0];
                    break;
                }
            }

            if (nui == null)
            {
                return;
            }
            try
            {
                // Start the sensor!
                nui.Start();
            }
            catch (IOException)
            {
                // Some other application is streaming from the same Kinect sensor
                nui = null;
            }

            ResetScreenPoint();
            SetPerspective();
            ResetSearchArea();

            GetKeyboardState(VirKey);

            nui.DepthStream.Enable(DepthImageFormat.Resolution640x480Fps30);
            nui.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);
            nui.DepthStream.Range = DepthRange.Near;
            nui.AllFramesReady += new EventHandler<AllFramesReadyEventArgs>(nui_AllFramesReady);
            colorBitmap = new WriteableBitmap(nui.DepthStream.FrameWidth, nui.DepthStream.FrameHeight, 96.0, 96.0, PixelFormats.Bgr32, null);
            depthPixels = new DepthImagePixel[nui.DepthStream.FramePixelDataLength];
            initDepthPixels = new DepthImagePixel[nui.DepthStream.FramePixelDataLength];
            
            setup = new SetUp();
            setup.Owner = this;
            setup.Show();
            ((App)System.Windows.Application.Current).SetUp.Add(setup);

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            nui.Stop();
            Environment.Exit(0);
        }

        private void open_image(string name, System.Windows.Controls.Image img)
        {
            var uriSource = new Uri(name, UriKind.Relative);
            img.Source = new BitmapImage(uriSource);
        }

        private void nui_AllFramesReady(object sender, AllFramesReadyEventArgs e)
        {
            if (!start)
                return;
            using (ColorImageFrame image = e.OpenColorImageFrame())
            {
                if (image != null)
                {
                    if (_colorPixels.Length != image.PixelDataLength)
                    {
                        _colorPixels = new byte[image.PixelDataLength];
                    }
                    image.CopyPixelDataTo(_colorPixels);
                }
            }
            using (DepthImageFrame depthImageFrame = e.OpenDepthImageFrame())
            {
                if (depthImageFrame == null)
                    return;

                depthImageFrame.CopyDepthImagePixelDataTo(depthPixels);

                if (_depthPixels.Length != depthImageFrame.PixelDataLength)
                {
                    _depthPixels = new short[depthImageFrame.PixelDataLength];
                    mappedDepthLocations = new ColorImagePoint[depthImageFrame.PixelDataLength];
                }

                depthImageFrame.CopyPixelDataTo(_depthPixels);


                int colorPixelIndex = 0;
                // Depth값 2차원 배열로 저장
                //Input2Dmatrix(initdepthPixel, init);
                for (int i = 0; i < SCREEN_PIXEL_HEIGHT; i++)
                {
                    for (int j = 0; j < SCREEN_PIXEL_WIDTH; j++)
                    {
                        if (init)
                            initdepthPixel[i, j] = depthPixels[SCREEN_PIXEL_WIDTH * i + j].Depth;
                        depthPixel[i, j] = depthPixels[SCREEN_PIXEL_WIDTH * i + j].Depth;

                        bitmapBits[colorPixelIndex + 3] = 255;
                        bitmapBits[colorPixelIndex + 2] = _colorPixels[colorPixelIndex + 2];
                        bitmapBits[colorPixelIndex + 1] = _colorPixels[colorPixelIndex + 1];
                        bitmapBits[colorPixelIndex] = _colorPixels[colorPixelIndex];
                        colorPixelIndex += COLOR_CHANNEL;
                    }
                }
                init = false;
            }
            this.nui.MapDepthFrameToColorFrame(DepthImageFormat.Resolution640x480Fps30, _depthPixels, ColorImageFormat.RgbResolution640x480Fps30, mappedDepthLocations);

            for (int i = 0; i < SCREEN_PIXEL_HEIGHT; i++)
            {
                for (int j = 0; j < SCREEN_PIXEL_WIDTH; j++)
                {

                    int currentDepth = depthPixel[i, j];
                    int initDepth = initdepthPixel[i, j];
                    short subDepth;

                    if (currentDepth > DEPTH_MAX_LIMIT || initDepth > DEPTH_MAX_LIMIT)
                        subDepth = 0;
                    else
                        subDepth = (short)((initDepth - currentDepth < 0) ? 0 : (initDepth - currentDepth));

                    if ((BLUE_COLOR_LIMIT < subDepth && subDepth <= RED_COLOR_LIMIT))
                    {
                        ColorImagePoint point = mappedDepthLocations[i * SCREEN_PIXEL_WIDTH + j];

                        if ((point.X >= 0 && point.X < SCREEN_PIXEL_WIDTH) && (point.Y >= 0 && point.Y < SCREEN_PIXEL_HEIGHT))
                        {
                            int baseIndex = (point.Y * SCREEN_PIXEL_WIDTH + point.X) * COLOR_CHANNEL;
                            bitmapBits[baseIndex] = 0;
                            bitmapBits[baseIndex + 1] = 0;
                            bitmapBits[baseIndex + 2] = 255;
                        }
                    }
                }
            }
            for (int i = 0; i < depthPixels.Length; ++i)
            {
                // Point 최대 개수 설정
                if (pointCnt > USER_CNT)
                    break;
               
                // SCREEN 내에서 터치 이벤트 발생
                if (bitmapBits[i * COLOR_CHANNEL + 1] == 0 && bitmapBits[i * COLOR_CHANNEL + 2] == 255 &&
                i % SCREEN_PIXEL_WIDTH >= SearchArea[0] && i % SCREEN_PIXEL_WIDTH <= SearchArea[1] &&
                i / SCREEN_PIXEL_WIDTH >= SearchArea[2] && i / SCREEN_PIXEL_WIDTH <= SearchArea[3])
                {
                    setPoint(i);     // 빨간색을 가진 Pixel을 찾는 재귀 함수

                    if (pixelCnt > PIXEL_CNT_MIN_LIMIT && pixelCnt < PIXEL_CNT_MAX_LIMIT)  // 일정 픽셀이상 Point 인식
                    {
                        double transX = (Perspective[0] * s_Row / pixelCnt + Perspective[1] * s_Col / pixelCnt + Perspective[2])
                                      / (Perspective[6] * s_Row / pixelCnt + Perspective[7] * s_Col / pixelCnt + 1);
                        double transY = (Perspective[3] * s_Row / pixelCnt + Perspective[4] * s_Col / pixelCnt + Perspective[5])
                                      / (Perspective[6] * s_Row / pixelCnt + Perspective[7] * s_Col / pixelCnt + 1);
                        refresh(SCREEN_PIXEL_WIDTH-transX, transY);
                    }
                    // 변수 초기화
                    s_Row = 0;
                    s_Col = 0;
                    pixelCnt = 0;
                }
            }

            //화면 캘리 함수 호출
            if (ScreenDraw)
            {
                if (PointList.First != null)
                    Calibration();
                else
                    frameCnt = 0;
            }

            //사라진 포인트 삭제
            removeNoneExist();

            //마우스 이벤트 함수
            if (mouseUse)
                mouseEvents();

            // 사용자 제한수 보다 많은 입력 즉 뎁스값 오류면 옵션창 호출
            if (pointCnt > USER_CNT)
            {
                if (!optionFlag)
                {
                    open_image(@"images\option_1_hover.png", option);
                    setup = new SetUp();
                    setup.Owner = this;
                    setup.Show();
                    ((App)System.Windows.Application.Current).SetUp.Add(setup);

                    optionFlag = true;
                }
            }
            colorBitmap.WritePixels(new Int32Rect(0, 0, colorBitmap.PixelWidth, colorBitmap.PixelHeight), bitmapBits, colorBitmap.PixelWidth * sizeof(int), 0);
        }



    }
}