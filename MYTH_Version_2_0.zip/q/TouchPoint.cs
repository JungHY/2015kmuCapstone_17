﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KinectUI
{
    class TouchPoint
    {
        private double X;               // X좌표
        private double Y;               // Y좌표
        private bool exist;             // 이전 프레임과 존재여부 판별
        private bool click;             // 클릭이벤트 발생 Flag
        private int revision;            // 짧은 프레임 내 포인트 삭제 방지
        public TouchPoint(double x, double y)
        {
            this.X = x;
            this.Y = y;
            this.exist = false;
            this.click = false;
            this.revision = 0;
        }
        public TouchPoint(TouchPoint p)
        {
            this.X = p.getX();
            this.Y = p.getY();
            this.exist = p.getExist();
            this.click = p.getclick();
            this.revision = p.getrevision();
        }
        //Private 변수 Get, Set 함수
        public double getX()
        {
            return this.X;
        }
        public double getY()
        {
            return this.Y;
        }
        public bool getExist()
        {
            return this.exist;
        }
        public bool getclick()
        {
            return this.click;
        }
        public int getrevision()
        {
            return this.revision;
        }
        public void setX(double x)
        {
            this.X = x;
        }
        public void setY(double y)
        {
            this.Y = y;
        }
        public void setExist(bool e)
        {
            this.exist = e;
        }
        public void setclick(bool e)
        {
            this.click = e;
        }
        public void setrevision(int r)
        {
            this.revision = r;
        }
        public void revisionPlus()
        {
            this.revision++;
        }
    }
}
