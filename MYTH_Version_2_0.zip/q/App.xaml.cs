﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace KinectUI
{
    /// <summary>
    /// App.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class App : Application
    {

        private List<SetUp> setups = new List<SetUp>();
        private List<PenTool> pentools = new List<PenTool>();

        public List<SetUp> SetUp
        {
            get
            {
                return setups;
            }
            set
            {
                setups = value;
            }
        }
        public List<PenTool> PenTool
        {
            get
            {
                return pentools;
            }
            set
            {
                pentools = value;
            }
        }
    }
}
