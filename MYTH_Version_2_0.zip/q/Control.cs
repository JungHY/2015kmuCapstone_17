﻿using System;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Kinect;
using System.Windows.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;

namespace KinectUI
{
    public partial class ToolBar
    {

        public void mouse_doing(double x, double y)
        {
            if (screenCnt > SQUARE_POINT_CNT-1)
                return;

            screenPoint[screenCnt].X = x;
            screenPoint[screenCnt].Y = y;
            Canvas.SetLeft(myEllipse[screenCnt], x);
            Canvas.SetTop(myEllipse[screenCnt], y);
            screenCnt++;
            if (screenCnt == SQUARE_POINT_CNT)
                DrawScreen();
        }

        // TouchPoint Search 함수
        public void setPoint(int i)
        {
            if (i < 0 || i >= SCREEN_PIXEL_WIDTH * SCREEN_PIXEL_HEIGHT || pixelCnt > PIXEL_CNT_MAX_LIMIT)
                return;

            if (bitmapBits[i * COLOR_CHANNEL + 1] != 0 || bitmapBits[i * COLOR_CHANNEL + 2] != 255)
                return;

            bitmapBits[i * COLOR_CHANNEL + 1] = 1; // 한번 지나간곳은 +로 바꿔서 안들리게함
            pixelCnt++; // 픽셀카운트
            s_Col += i / SCREEN_PIXEL_WIDTH;
            s_Row += i % SCREEN_PIXEL_WIDTH;

            setPoint(i + 1);
            setPoint(i - 1);
            setPoint(i + SCREEN_PIXEL_WIDTH);
            setPoint(i - SCREEN_PIXEL_WIDTH);
        }

        string keyboardName = System.Environment.CurrentDirectory + @"\keyboardTool.exe";
        string filenameStr = "";
        string filename()
        {
            return string.Format("{0}.png", System.DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss"));
        }

        private void initOpacity(bool openFlag)
        {
            option.Opacity = openFlag ? 0 : 1;
            pen.Opacity = openFlag ? 0 : 1;
            keyboard.Opacity = openFlag ? 0 : 1;
            capture.Opacity = openFlag ? 0 : 1;
            usermode.Opacity = openFlag ? 0 : 1;
            quit.Opacity = openFlag ? 0 : 1;
        }

        // 오픈 버튼 이벤트
        private void open_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(openFlag ? @"images\close.png" : @"images\open.png", open);
        }
        private void open_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(openFlag ? @"images\close_hover.png" : @"images\open_hover.png", open);
        }
        private void open_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            open_image(openFlag ? @"images\open_hover.png" : @"images\close_hover.png", open);

            //create menu
            initOpacity(openFlag);

            openFlag = !openFlag;
        }

        // 펜 버튼 이벤트
        private void pen_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(penFlag ? @"images\pen_1.png" : @"images\pen.png", pen);
        }
        private void pen_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(penFlag ? @"images\pen_1_hover.png" : @"images\pen_hover.png", pen);
        }
        private void pen_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            open_image(penFlag ? @"images\pen.png" : @"images\pen_1_hover.png", pen);

            inkCanvas.Background = (System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFromString(penFlag ? "#00898989" : "#01898989");
            penMoveLimit = penFlag ? PEN_MOVE_MAX_LIMIT : PEN_MOVE_MIN_LIMIT;

            if (penFlag)
            {
                inkCanvas.Strokes.Clear();
                if (pentool != null)
                {
                    pentool.Close();
                    penTool_Flag = false;
                }
            }
            penFlag = !penFlag;
        }
        private TouchPoint catmull_rom_splines(double t_const)
        {
            TracePoint.CopyTo(penPointList, 0);

            int length = penPointList.Length;
            double[] t = new double[MAX_POINT_SPLINE - 1];

            for (int i = length; i < MAX_POINT_SPLINE; i++)
                penPointList[i] = penPointList[length - 1];

            t[0] = t_const;
            t[1] = t[0] * t[0];
            t[2] = t[0] * t[1];

            return calculateCurve(penPointList, t);
        }

        private TouchPoint calculateCurve(TouchPoint[] points, double[] t)
        {
            TouchPoint result = new TouchPoint(0, 0);
            result.setX(Contants.calc_spline_curve(points[0].getX(), points[1].getX(), points[2].getX(), points[3].getX(), t));
            result.setY(Contants.calc_spline_curve(points[0].getY(), points[1].getY(), points[2].getY(), points[3].getY(), t));

            return result;
        }
        // 키보드 버튼 이벤트
        private void keyboard_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(keyboardFlag ? @"images\keyboard_1.png" : @"images\keyboard.png", keyboard);
        }
        private void keyboard_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(keyboardFlag ? @"images\keyboard_1_hover.png" : @"images\keyboard_hover.png", keyboard);
        }
        private void keyboard_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            open_image(keyboardFlag ? @"images\keyboard_hover.png" : @"images\keyboard_1_hover.png", keyboard);
            if (!keyboardFlag)
            {
                foreach (var proc in Process.GetProcesses())
                {
                    if (proc.ProcessName == "keyboardTool")
                    {
                        SetForegroundWindow(proc.MainWindowHandle);
                        return;
                    }
                }

                keyProcess = new Process();
                keyProcess.StartInfo.FileName = keyboardName;
                keyProcess.Start();
                keyProcess.Dispose();
            }
            else
            {
                Process[] processList = Process.GetProcessesByName("keyboardTool");
                processList[0].Kill();
            }
            keyboardFlag = !keyboardFlag;
        }

        // 캡쳐 버튼 이벤트
        private void capture_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(captureFlag ? @"images\capture_1.png" : @"images\capture.png", capture);
        }
        private void capture_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(captureFlag ? @"images\capture_1_hover.png" : @"images\capture_hover.png", capture);
        }
        private void capture_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!captureFlag)
            {
                open_image(@"images\capture_1_hover.png", capture);

                Bitmap printScreen = new Bitmap(Screen.PrimaryScreen.Bounds.Width, System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height);
                System.Drawing.Graphics graphics = System.Drawing.Graphics.FromImage(printScreen);
                graphics.CopyFromScreen(0, 0, 0, 0, printScreen.Size);

                string fn = filename();
                filenameStr = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "/" + fn;
                printScreen.Save(filenameStr, ImageFormat.Png);
            }
        }


        // 유저모드 버튼 이벤트
        private void usermode_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(usermodeFlag ? @"images\usermode_1.png" : @"images\usermode.png", usermode);
        }
        private void usermode_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(usermodeFlag ? @"images\usermode_1_hover.png" : @"images\usermode_hover.png", usermode);
        }
        private void usermode_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            open_image(usermodeFlag ? @"images\usermode.png" : @"images\usermode_1_hover.png", usermode);
            mode = usermodeFlag ? 1 : 2;

            usermodeFlag = !usermodeFlag;
        }

        // 옵션 버튼 이벤트
        private void option_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(optionFlag ? @"images\option_1.png" : @"images\option.png", option);
        }
        private void option_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(optionFlag ? @"images\option_1_hover.png" : @"images\option_hover.png", option);
        }
        private void option_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            open_image(optionFlag ? @"images\option.png" : @"images\option_1_hover.png", option);
            if (!optionFlag)
            {
                setup = new SetUp();
                setup.Owner = this;
                setup.Show();
                ((App)System.Windows.Application.Current).SetUp.Add(setup);
            }
            else
            {
                setup.Close();
            }
            optionFlag = !optionFlag;
        }

        // 종료 버튼 이벤트
        private void quit_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(@"images\quit_2.png", quit);
        }
        private void quit_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            open_image(@"images\quit_hover.png", quit);
        }
        private void quit_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Environment.Exit(1);
        }

        private void Preview_Mouse_Right_Button_Down(object sender, MouseButtonEventArgs e)
        {
            if (!penTool_Flag)
            {
                pentool = new PenTool();
                pentool.Owner = this;
                System.Windows.Point p;
                p = new System.Windows.Point(0, 0);
                MouseEvent.GetCursorPos(out p);
                pentool.Left = p.X;
                pentool.Top = p.Y;
                pentool.Show();
                ((App)System.Windows.Application.Current).PenTool.Add(pentool);
            }
            else
            {
                pentool.Close();
            }
            penTool_Flag = !penTool_Flag;
        }

        // 새로 추가된 부분------------------------------------------
        public double avg(double a, double b)
        {
            return ((a + b) / 2);
        }
        public double pow_Distance_2(double a, double b)
        {
            return (Math.Pow(a, 2) + Math.Pow(b, 2));
        }
        // ----------------------------------------------------------



        // Mouse Gesture 이벤트 설정 함수
        public void mouseEvents()
        {
            if (pointCnt == 0)
                gestureFlag = false;
            // Point가 하나일때 일반적 마우스 사용 & 1인 모드
            else if (pointCnt == 1 && mode == 1)
            {
                if (penFlag && TracePoint.Count >= 1)
                {
                    for (int i = 1; i < SPLINE_T; i++) //A와 B 사이를 점 10개로 분할
                    {
                        TouchPoint p = new TouchPoint(catmull_rom_splines(i / SPLINE_T));
                        MoveAt(p.getX(), p.getY());
                    }
                }

                MoveAt(PointList.First.Value.getX(), PointList.First.Value.getY());
                if (!PointList.First.Value.getclick())
                {
                    Down(MouseButton.Left);
                    PointList.First.Value.setclick(true);
                    if (!ScreenDraw)
                    {
                        rightPoint = new System.Windows.Point(PointList.First.Value.getX(), PointList.First.Value.getY());
                        frameCnt = 0;
                    }
                }
                else
                {
                    if ((rightPoint.X - PointList.First.Value.getX()) * (rightPoint.X - PointList.First.Value.getX()) +
                        (rightPoint.Y - PointList.First.Value.getY()) * (rightPoint.Y - PointList.First.Value.getY()) < SCREEN_DISTANCE_LIMIT)
                    {
                        frameCnt++;
                    }
                    else
                    {
                        frameCnt = 0;
                    }
                    if (frameCnt > PRESSED_FRAME_CNT && rightFlag)
                    {
                        Down(MouseButton.Right);
                        Up(MouseButton.Right);
                        Up(MouseButton.Left);
                        frameCnt = 0;
                        rightFlag = false;
                    }
                }
            }
            // Point가 둘일때 Touch Gesture 사용 
            else if (pointCnt == 2 && mode == 1)
            {
                GESTURE_MOVE_LIMIT = 100;
                double seta = 45.0, avg_Seta = 0, seta1 = 0, seta2 = 0;
                double pre_distance = 0, cur_distance;

                Up(MouseButton.Left);
                gestureFlag = true;

                pre_Point1.X = PointList.First.Value.getX();
                pre_Point1.Y = PointList.First.Value.getY();
                pre_Point2.X = PointList.First.Next.Value.getX();
                pre_Point2.Y = PointList.First.Next.Value.getY();

                if (!PointList.First.Next.Value.getclick())
                {
                    PointList.First.Value.setclick(true);
                    PointList.First.Next.Value.setclick(true);
                }
                else
                {
                    double x1, y1, x2, y2;

                    pre_distance = pow_Distance_2((pre_Point2.X - pre_Point1.X), (pre_Point2.Y - pre_Point1.Y));

                    x1 = PointList.First.Value.getX() - pre_Point1.X;
                    x2 = PointList.First.Next.Value.getX() - pre_Point2.X;

                    y1 = PointList.First.Value.getY() - pre_Point1.Y;
                    y2 = PointList.First.Next.Value.getY() - pre_Point2.Y;

                    seta1 = Math.Atan2(-y1, x1) * 180 / Math.PI;
                    seta2 = Math.Atan2(-y2, x2) * 180 / Math.PI;

                    // 두각의 차이값을 최대 180도 지정
                    seta = ((Math.Abs(seta1 - seta2) <= 180) ? Math.Abs(seta1 - seta2) : (360 - Math.Abs(seta1 - seta2)));
                }

                // 스크롤 이벤트
                if (seta <= 30 && seta != 0)
                {
                    //예외처리
                    if (seta1 * seta2 < 0)
                    {
                        if (seta1 < 0)
                            seta1 += 360;
                        else
                            seta2 += 360;
                    }

                    //두점의 평균방향
                    double seta_avg = avg(seta1, seta2);
                    avg_Seta = (seta_avg > 180) ? (seta_avg - 360) : seta_avg;

                    //휠 다운
                    if (avg_Seta >= WHEEL_VARIATION && avg_Seta <= (180 - WHEEL_VARIATION))
                    {
                        Down(MouseButton.Wheel);
                        Down(MouseButton.Wheel);
                    }
                    //휠 업
                    else if (avg_Seta <= -WHEEL_VARIATION && avg_Seta >= (WHEEL_VARIATION - 180))
                    {
                        Up(MouseButton.Wheel);
                        Up(MouseButton.Wheel);
                    }
                }
                //확대 축소 이벤트
                else if (seta >= 90 || (seta == 0 && (seta1 != 0 || seta2 != 0)))
                {
                    cur_distance = pow_Distance_2((pre_Point2.X - pre_Point1.X), (pre_Point2.Y - pre_Point1.Y));
                    //확대
                    if (cur_distance - pre_distance > SUB_DISTANCE_LIMIT)
                    {
                        keybd_event((byte)Keys.ControlKey, 0, 0, 0);
                        Up(MouseButton.Wheel);
                        Up(MouseButton.Wheel);
                        Up(MouseButton.Wheel);
                        keybd_event((byte)Keys.ControlKey, 0, 0x02, 0);
                    }
                    //축소
                    else if (cur_distance - pre_distance < -SUB_DISTANCE_LIMIT)
                    {
                        keybd_event((byte)Keys.ControlKey, 0, 0, 0);
                        Down(MouseButton.Wheel);
                        Down(MouseButton.Wheel);
                        Down(MouseButton.Wheel);
                        keybd_event((byte)Keys.ControlKey, 0, 0x02, 0);
                    }
                }
            }
            // 다인모드
            else if (mode == 2)
            {
                LinkedListNode<TouchPoint> P;
                for (P = PointList.First; P != null; P = P.Next)
                {
                    if (!P.Value.getclick())
                    {
                        MoveAt(P.Value.getX(), P.Value.getY());
                        Down(MouseButton.Left);
                        P.Value.setclick(true);
                    }
                }
            }
        }

        // 마우스 좌표 이동
        public void MoveAt(double x, double y)
        {
            //screen.width와 height를 변환할 사각형 크기로 교체
            SetCursorPos((int)((x / SCREEN_PIXEL_WIDTH) * COMPUTER_X), (int)((y / SCREEN_PIXEL_HEIGHT) * COMPUTER_Y));

        }


        // 마우스 Down 이벤트
        public void Down(MouseButton Button)
        {
            MouseEventFlag Flag = new MouseEventFlag();

            switch (Button)
            {
                case MouseButton.Left: Flag = MouseEventFlag.LeftDown; break;
                case MouseButton.Right: Flag = MouseEventFlag.RightDown; break;
                case MouseButton.Middle: Flag = MouseEventFlag.MiddleDown; break;
                case MouseButton.X: Flag = MouseEventFlag.XDown; break;
                case MouseButton.Wheel: Flag = MouseEventFlag.Wheel; break;
            }

            mouse_event((int)Flag, 0, 0, (Flag == MouseEventFlag.Wheel) ? -WHEEL_VARIATION : 0, IntPtr.Zero);
        }

        // 마우스 Up 이벤트
        public void Up(MouseButton Button)
        {
            MouseEventFlag Flag = new MouseEventFlag();

            switch (Button)
            {
                case MouseButton.Left: Flag = MouseEventFlag.LeftUp; break;
                case MouseButton.Right: Flag = MouseEventFlag.RightUp; break;
                case MouseButton.Middle: Flag = MouseEventFlag.MiddleUp; break;
                case MouseButton.X: Flag = MouseEventFlag.XUp; break;
                case MouseButton.Wheel: Flag = MouseEventFlag.Wheel; break;
            }

            mouse_event((int)Flag, 0, 0, (Flag == MouseEventFlag.Wheel) ? WHEEL_VARIATION : 0, IntPtr.Zero);
        }

        // 화면 캘리브레이션 함수
        public void Calibration()
        {

            if (PointList.First.Next != null)
                frameCnt = 0;
            else
                frameCnt++;

            // 모서리 4개 생성시 화면 크기 저장 
            if (screenCnt == SQUARE_POINT_CNT)
            {
                DrawScreen();
            }
            // 모서리 저장
            else if (frameCnt > PRESSED_FRAME_CNT)
            {
                bool save = true; // 같은 위치에 모서리 생성 방지 Flag
                for (int i = 0; i < screenCnt; i++)
                {
                    double distance = pow_Distance_2((screenPoint[i].X - PointList.First.Value.getX()), (screenPoint[i].Y - PointList.First.Value.getY()));
                    if (distance < SCREEN_DISTANCE_LIMIT)
                    {
                        save = false;
                        break;
                    }
                }
                if (save)
                {
                    screenPoint[screenCnt].X = PointList.First.Value.getX();
                    screenPoint[screenCnt].Y = PointList.First.Value.getY();
                    screenCnt++;
                    Canvas.SetLeft(myEllipse[screenCnt - 1], PointList.First.Value.getX());
                    Canvas.SetTop(myEllipse[screenCnt - 1], PointList.First.Value.getY());
                }
                frameCnt = 0;
            }

        }
        public void SetPerspective()
        {
            System.Windows.Point[] screenInit = new System.Windows.Point[4]; // SCREEN 4 모퉁이 좌표
            screenInit[0] = new System.Windows.Point(0, 0);
            screenInit[1] = new System.Windows.Point(640, 0);
            screenInit[2] = new System.Windows.Point(640, 480);
            screenInit[3] = new System.Windows.Point(0, 480);
            for (int i = 0; i < 8; i++)
            {
                Perspective[i] = 0;
            }
            double[,] matrix = new double[8, 8];
            
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (i % 2 == 0)
                    {
                        matrix[i, ((i % 2) * 3) + j] = screenPoint[i / 2].X; matrix[i, ((i % 2) * 3) + j + 1] = screenPoint[i / 2].Y; matrix[i, ((i % 2) * 3) + j + 2] = 1;
                        j += 6;
                        matrix[i, j++] = -1 * screenPoint[i / 2].X * screenInit[i / 2].X; matrix[i, j] = -1 * screenPoint[i / 2].Y * screenInit[i / 2].X;
                    }
                    else
                    {
                        matrix[i, ((i % 2) * 3) + j] = screenPoint[i / 2].X; matrix[i, ((i % 2) * 3) + j + 1] = screenPoint[i / 2].Y; matrix[i, ((i % 2) * 3) + j + 2] = 1;
                        j += 6;
                        matrix[i, j++] = -1 * screenPoint[i / 2].X * screenInit[i / 2].Y; matrix[i, j] = -1 * screenPoint[i / 2].Y * screenInit[i / 2].Y;
                    }
                }
            }

            double[,] InversMatrix = GetInverseMatrix(matrix, 8);

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (j == 2 || j == 4)
                        Perspective[i] += InversMatrix[i, j] * SCREEN_PIXEL_WIDTH;
                    else if (j == 5 || j == 7)
                        Perspective[i] += InversMatrix[i, j] * SCREEN_PIXEL_HEIGHT;
                }
            }

        }
        public double[,] GetInverseMatrix(double[,] input, int dim)
        {
            double[,] adjMatrix = GetAdjMatrix(input, dim);
            double divideDet = 1 / GetDeterminant(input, dim);

            double[,] output = new double[dim, dim];
            for (int y = 0; y < dim; ++y)
            {
                for (int x = 0; x < dim; ++x)
                {
                    output[y, x] = adjMatrix[y, x] * divideDet;
                }
            }
            return output;
        }

        public double[,] GetAdjMatrix(double[,] input, int dim)
        {
            double[,] coFactorMatrix = GetCoFactorMatrix(input, dim);
            double[,] output = GetTransposeMatrix(coFactorMatrix, dim);

            return output;
        }

        public double[,] GetTransposeMatrix(double[,] input, int dim)
        {
            double[,] output = new double[dim, dim];
            for (int y = 0; y < dim; ++y)
            {
                for (int x = 0; x < dim; ++x)
                {
                    output[y, x] = input[x, y];
                }
            }
            return output;
        }

        public double[,] GetCoFactorMatrix(double[,] input, int dim)
        {
            double[,] output = new double[dim, dim];
            for (int y = 0; y < dim; ++y)
            {
                for (int x = 0; x < dim; ++x)
                {
                    double[,] minorMatrix = GetMinorMatrix(input, dim, x, y);

                    //여인수 c_yx = |M_yx| * (-1)^(x+y)
                    output[y, x] = GetDeterminant(minorMatrix, dim - 1) * (double)System.Math.Pow(-1, x + 1 + y + 1);
                }
            }
            return output;
        }

        public double[,] GetMinorMatrix(double[,] originalMatrix, int dim, int x, int y)
        {
            double[,] minorMatrix = new double[dim - 1, dim - 1];
            int getY = 0;
            for (int yy = 0; yy < dim; ++yy)
            {
                if (yy == y) continue;
                int getX = 0;
                for (int xx = 0; xx < dim; ++xx)
                {
                    if (xx == x) continue;
                    minorMatrix[getY, getX] = originalMatrix[yy, xx];

                    ++getX;
                }
                ++getY;
            }
            return minorMatrix;
        }

        public double GetDeterminant(double[,] input, int dim)
        {
            //행렬식은
            // SUM (  a_1n * ( ((-1)^(n+1)) * |M_1n| )  )
            //즉, SUM ( a_1n * c_1n )
            //단, 0<n

            double det = 0;
            if (dim == 2)
            {
                det += Get2x2Determinant(input);
            }
            else
            {
                //A_1n 성분의 소행렬식만 뽑으면 된다.
                for (int x = 0; x < dim; ++x)
                {
                    double[,] minorMatrix = GetMinorMatrix(input, dim, x, 0);

                    //|M_1n|
                    double minorOfDet = GetDeterminant(minorMatrix, dim - 1);
                    //c_n1 = |M_1n| * ((-1)^(n+1)) 
                    double cofactor = minorOfDet * (double)System.Math.Pow(-1, x + 2);
                    //det = c_1n*a_1n
                    det += cofactor * input[0, x];
                }
            }

            return det;

        }

        public double Get2x2Determinant(double[,] input)
        {
            //a*d - b*c
            return (input[0, 0] * input[1, 1]) - (input[0, 1] * input[1, 0]);
        }

        public void SetPointOrder()
        {
            System.Windows.Point avePoint = new System.Windows.Point(0, 0);
            System.Windows.Point[] tempPoint = new System.Windows.Point[4];

            for (int i = 0; i < 4; i++)
            {
                tempPoint[i] = screenPoint[i];
                avePoint.X += screenPoint[i].X/4;
                avePoint.Y += screenPoint[i].Y/4;
            }
            
            for (int i = 0; i < SQUARE_POINT_CNT; i++)
            {
                if (avePoint.X - screenPoint[i].X > 0 && avePoint.Y - screenPoint[i].Y > 0 && i != 0)
                    tempPoint[0] = screenPoint[i];

                else if (avePoint.X - screenPoint[i].X < 0 && avePoint.Y - screenPoint[i].Y > 0 && i != 1)
                    tempPoint[1] = screenPoint[i];

                else if (avePoint.X - screenPoint[i].X < 0 && avePoint.Y - screenPoint[i].Y < 0 && i != 2)
                    tempPoint[2] = screenPoint[i];
                else if (avePoint.X - screenPoint[i].X > 0 && avePoint.Y - screenPoint[i].Y < 0 && i != 3)
                    tempPoint[3] = screenPoint[i];
            }
            screenPoint = tempPoint;
        }

        public void ResetScreenPoint()
        {
            screenPoint[0] = new System.Windows.Point(0, 0);
            screenPoint[1] = new System.Windows.Point(640, 0);
            screenPoint[2] = new System.Windows.Point(640, 480);
            screenPoint[3] = new System.Windows.Point(0, 480);
        }
        public void ResetSearchArea()
        {
            SearchArea[0] = 0;
            SearchArea[1] = (int)SCREEN_PIXEL_WIDTH;
            SearchArea[2] = 0;
            SearchArea[3] = (int)SCREEN_PIXEL_HEIGHT;
        }
        public void DrawScreen()
        {
            int[] minX = new int[2] { MIN_ARRAY_INIT, MIN_ARRAY_INIT };
            int[] minY = new int[2] { MIN_ARRAY_INIT, MIN_ARRAY_INIT };
            int[] maxX = new int[2] { MAX_ARRAY_INIT, MAX_ARRAY_INIT };
            int[] maxY = new int[2] { MAX_ARRAY_INIT, MAX_ARRAY_INIT };

            // 모서리 LeftTop부터 시계방향 정렬
            SetPointOrder();

            for (int i = 0; i < 4; i++)
            {
                int idx = i;
                MyLine[i].X1 = screenPoint[idx].X;
                MyLine[i].Y1 = screenPoint[idx].Y;
                idx = (i == 3) ? 0 : i + 1;
                MyLine[i].X2 = screenPoint[idx].X;
                MyLine[i].Y2 = screenPoint[idx].Y;
            }
            set_myLine();
            for (int i = 0; i < SQUARE_POINT_CNT; i++)
            {
                if (minX[0] > screenPoint[i].X)
                    minX[0] = (int)screenPoint[i].X;
                if (minY[0] > screenPoint[i].Y)
                    minY[0] = (int)screenPoint[i].Y;
                if (maxX[0] < screenPoint[i].X)
                    maxX[0] = (int)screenPoint[i].X;
                if (maxY[0] < screenPoint[i].Y)
                    maxY[0] = (int)screenPoint[i].Y;
            }
            for (int i = 0; i < 4; i++)
            {
                if (minX[1] > screenPoint[i].X && minX[0] != screenPoint[i].X)
                    minX[1] = (int)screenPoint[i].X;
                if (minY[1] > screenPoint[i].Y && minY[0] != screenPoint[i].Y)
                    minY[1] = (int)screenPoint[i].Y;
                if (maxX[1] < screenPoint[i].X && maxX[0] != screenPoint[i].X)
                    maxX[1] = (int)screenPoint[i].X;
                if (maxY[1] < screenPoint[i].Y && maxY[0] != screenPoint[i].Y)
                    maxY[1] = (int)screenPoint[i].Y;

                Canvas.SetLeft(myEllipse[i], -SCREEN_DISTANCE_LIMIT);
                Canvas.SetTop(myEllipse[i], -SCREEN_DISTANCE_LIMIT);
            }

            SearchArea[0] = (minX[0] < minX[1]) ? minX[0] : minX[1];
            SearchArea[1] = (maxX[0] > maxX[1]) ? maxX[0] : maxX[1];
            SearchArea[2] = (minY[0] < minY[1]) ? minY[0] : minY[1];
            SearchArea[3] = (maxY[0] > maxY[1]) ? maxY[0] : maxY[1];
            ScreenDraw = false;
            screenCnt = 0;
            mouseUse = true;
            //인벌스 함수 a~h까지 구함
            SetPerspective();
        }
    }
}
