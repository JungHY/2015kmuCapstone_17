﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KinectUI
{
    /// <summary>
    /// SetUp.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class SetUp : Window
    {

        public SetUp()
        {
            InitializeComponent();
            Video.MouseLeftButtonDown += new MouseButtonEventHandler(Video_MouseLeftButtonDown);
        }
        
        void Video_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (((ToolBar)(this.Owner)).get_ScreenDraw())
            {
                ((ToolBar)(this.Owner)).mouse_doing(e.GetPosition(Video).X, e.GetPosition(Video).Y);
            }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.Left = 500.0;
            this.Top = 150.0;
            ((ToolBar)(this.Owner)).init_myEllipse(); //myEllipse 동적생성(포문)
            ((ToolBar)(this.Owner)).init_myLine();    //myEllipse 동적생성(포문)
            ((ToolBar)(this.Owner)).set_mouseUse(false);

            ((ToolBar)(this.Owner)).set_myLine();
            for (int i = 0; i < 4; i++)
            {
                int idx = i;
                ((ToolBar)(this.Owner)).get_MyLine(i).X1 = ((ToolBar)(this.Owner)).get_screenPoint(idx).X;
                ((ToolBar)(this.Owner)).get_MyLine(i).Y1 = ((ToolBar)(this.Owner)).get_screenPoint(idx).Y;
                idx = (i == 3) ? 0 : i+1;
                ((ToolBar)(this.Owner)).get_MyLine(i).X2 = ((ToolBar)(this.Owner)).get_screenPoint(idx).X;
                ((ToolBar)(this.Owner)).get_MyLine(i).Y2 = ((ToolBar)(this.Owner)).get_screenPoint(idx).Y;
                leftCanvas.Children.Add(((ToolBar)(this.Owner)).get_MyLine(i));
            }

            ((ToolBar)(this.Owner)).set_myEllipse();//밑 포문 내 3줄 미리수행
            for (int i = 0; i < 4; i++)
            {
                leftCanvas.Children.Add(((ToolBar)(this.Owner)).get_myEllipse(i)); 
                Canvas.SetLeft(((ToolBar)(this.Owner)).get_myEllipse(i), -100);
                Canvas.SetTop(((ToolBar)(this.Owner)).get_myEllipse(i), -100);
            }
            Video.Source = ((ToolBar)(this.Owner)).get_colorBitmap();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
        }

        // SCREENSIZE 재설정 함수
        private void ScreenSize_Click(object sender, RoutedEventArgs e)
        {
            ((ToolBar)(this.Owner)).ResetScreenPoint();
            ((ToolBar)(this.Owner)).SetPerspective();
            ((ToolBar)(this.Owner)).ResetSearchArea();

            ((ToolBar)(this.Owner)).set_ScreenDraw(true);
            ((ToolBar)(this.Owner)).Reset_screen();
            ((ToolBar)(this.Owner)).set_screenCnt(0);
            for (int i = 0; i < 4; i++)
            {
                Canvas.SetLeft(((ToolBar)(this.Owner)).get_myEllipse(i), -100);
                Canvas.SetTop(((ToolBar)(this.Owner)).get_myEllipse(i), -100);
            }
            ((ToolBar)(this.Owner)).set_mouseUse(false);
        }
        // 초기 Depth값 재설정 함수
        private void DepthInit_Click(object sender, RoutedEventArgs e)
        {
            ((ToolBar)(this.Owner)).set_initdepthPixel();
        }

        // Kinect 센서 Start & Stop 함수
        private void StartStop_Click(object sender, RoutedEventArgs e)
        {
            if (((ToolBar)(this.Owner)).get_start())
                ((ToolBar)(this.Owner)).set_start(false);

            else ((ToolBar)(this.Owner)).set_start(true);

          //  ((ToolBar)(this.Owner)).set_start(!((ToolBar)(this.Owner)).get_start());
        }
        // 종료 버튼 함수
        private void Close_Click(object sender, RoutedEventArgs e)
        {

            var uriSource = new Uri(@"images\option.png", UriKind.Relative);
            ((ToolBar)(this.Owner)).option.Source = new BitmapImage(uriSource);
            ((ToolBar)(this.Owner)).set_optionFlag(false);
            this.Close();
        }
    }
}